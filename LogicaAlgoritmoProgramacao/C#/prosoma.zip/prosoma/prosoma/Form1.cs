﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prosoma
{
    public partial class soma : Form
    {
        public soma()
        {
            InitializeComponent();
        }

        private void projectsoma_Click(object sender, EventArgs e)
        {

        }

        private void lblVA_Click(object sender, EventArgs e)
        {
          
        }

        private void lblresultado_Click(object sender, EventArgs e)
        {
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnSomar_Click(object sender, EventArgs e)
        {
            //Variáveis
            int soma = 0;
            int valorA = 0;
            int valorB = 0;

            //Converter
            valor A = int.Parse(txtValorA.Text);
            valor B = int.Parse(txtValorB.Text);
          
            //Calculo
            soma = valorA + valorB;
            
            //exibir o dado
            txtResultado.Text = soma.ToString();
        }

        private void lblVB_Click(object sender, EventArgs e)
        {
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
