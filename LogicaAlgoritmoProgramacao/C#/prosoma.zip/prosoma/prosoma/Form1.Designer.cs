﻿namespace prosoma
{
    partial class soma
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.projectsoma = new System.Windows.Forms.Label();
            this.lblVA = new System.Windows.Forms.Label();
            this.lblVB = new System.Windows.Forms.Label();
            this.lblresultado = new System.Windows.Forms.Label();
            this.btnSomar = new System.Windows.Forms.Button();
            this.txtValorA = new System.Windows.Forms.TextBox();
            this.txtValorB = new System.Windows.Forms.TextBox();
            this.txtResultado = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // projectsoma
            // 
            this.projectsoma.AutoSize = true;
            this.projectsoma.Font = new System.Drawing.Font("Arial Narrow", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.projectsoma.Location = new System.Drawing.Point(65, 9);
            this.projectsoma.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.projectsoma.Name = "projectsoma";
            this.projectsoma.Size = new System.Drawing.Size(146, 31);
            this.projectsoma.TabIndex = 0;
            this.projectsoma.Text = "Projeto Soma";
            this.projectsoma.Click += new System.EventHandler(this.projectsoma_Click);
            // 
            // lblVA
            // 
            this.lblVA.AutoSize = true;
            this.lblVA.Font = new System.Drawing.Font("Arial Narrow", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVA.Location = new System.Drawing.Point(21, 70);
            this.lblVA.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblVA.Name = "lblVA";
            this.lblVA.Size = new System.Drawing.Size(92, 33);
            this.lblVA.TabIndex = 1;
            this.lblVA.Text = "Valor A";
            this.lblVA.Click += new System.EventHandler(this.lblVA_Click);
            // 
            // lblVB
            // 
            this.lblVB.AutoSize = true;
            this.lblVB.Font = new System.Drawing.Font("Arial Narrow", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVB.Location = new System.Drawing.Point(21, 118);
            this.lblVB.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblVB.Name = "lblVB";
            this.lblVB.Size = new System.Drawing.Size(92, 33);
            this.lblVB.TabIndex = 2;
            this.lblVB.Text = "Valor B";
            this.lblVB.Click += new System.EventHandler(this.lblVB_Click);
            // 
            // lblresultado
            // 
            this.lblresultado.AutoSize = true;
            this.lblresultado.Font = new System.Drawing.Font("Arial Narrow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblresultado.Location = new System.Drawing.Point(22, 210);
            this.lblresultado.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblresultado.Name = "lblresultado";
            this.lblresultado.Size = new System.Drawing.Size(101, 29);
            this.lblresultado.TabIndex = 3;
            this.lblresultado.Text = "Resultado";
            this.lblresultado.Click += new System.EventHandler(this.lblresultado_Click);
            // 
            // btnSomar
            // 
            this.btnSomar.Location = new System.Drawing.Point(157, 171);
            this.btnSomar.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btnSomar.Name = "btnSomar";
            this.btnSomar.Size = new System.Drawing.Size(62, 27);
            this.btnSomar.TabIndex = 4;
            this.btnSomar.Text = "soma";
            this.btnSomar.UseVisualStyleBackColor = true;
            this.btnSomar.Click += new System.EventHandler(this.btnSomar_Click);
            // 
            // txtValorA
            // 
            this.txtValorA.Location = new System.Drawing.Point(135, 82);
            this.txtValorA.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.txtValorA.Multiline = true;
            this.txtValorA.Name = "txtValorA";
            this.txtValorA.Size = new System.Drawing.Size(84, 20);
            this.txtValorA.TabIndex = 5;
            this.txtValorA.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // txtValorB
            // 
            this.txtValorB.Location = new System.Drawing.Point(135, 130);
            this.txtValorB.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.txtValorB.Multiline = true;
            this.txtValorB.Name = "txtValorB";
            this.txtValorB.Size = new System.Drawing.Size(84, 19);
            this.txtValorB.TabIndex = 6;
            // 
            // txtResultado
            // 
            this.txtResultado.Location = new System.Drawing.Point(157, 218);
            this.txtResultado.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.txtResultado.Multiline = true;
            this.txtResultado.Name = "txtResultado";
            this.txtResultado.Size = new System.Drawing.Size(62, 20);
            this.txtResultado.TabIndex = 7;
            this.txtResultado.Click += new System.EventHandler(this.lblresultado_Click);
            // 
            // soma
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(5F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(274, 306);
            this.Controls.Add(this.txtResultado);
            this.Controls.Add(this.txtValorB);
            this.Controls.Add(this.txtValorA);
            this.Controls.Add(this.btnSomar);
            this.Controls.Add(this.lblresultado);
            this.Controls.Add(this.lblVB);
            this.Controls.Add(this.lblVA);
            this.Controls.Add(this.projectsoma);
            this.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.Name = "soma";
            this.Text = "ProSoma";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label projectsoma;
        private System.Windows.Forms.Label lblVA;
        private System.Windows.Forms.Label lblVB;
        private System.Windows.Forms.Label lblresultado;
        private System.Windows.Forms.Button btnSomar;
        private System.Windows.Forms.TextBox txtValorA;
        private System.Windows.Forms.TextBox txtValorB;
        private System.Windows.Forms.TextBox txtResultado;
    }
}

