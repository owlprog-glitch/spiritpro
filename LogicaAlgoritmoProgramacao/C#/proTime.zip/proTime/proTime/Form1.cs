﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace proTime
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            cmbtime.SelectedIndex = 0;
        }

        private void btncalcular_Click(object sender, EventArgs e)
        {
            string lbresultado = "";
            switch (cmbtime.Text){
                case "AMERICA":
                    lbresultado = "O Time da Familia";
                    break;
                case "ATLETICO":
                    lbresultado = "Galão da Massa";
                    break;
                case "CRUZEIRO":
                    lbresultado = "Cruzeirão Cabuloso";
                    break;
            }

            //Exibir
            txtResultado.Text = lbresultado;
        }

        private void lbtimes_Click(object sender, EventArgs e)
        {

        }

        private void txtResultado_TextChanged(object sender, EventArgs e)
        {

        }

        private void cmbtime_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void lbtime_Click(object sender, EventArgs e)
        {

        }

        private void lbresultado_Click(object sender, EventArgs e)
        {

        }
    }
}
