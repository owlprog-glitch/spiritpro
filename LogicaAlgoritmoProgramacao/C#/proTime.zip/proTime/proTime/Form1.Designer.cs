﻿namespace proTime
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbtimes = new System.Windows.Forms.Label();
            this.lbtime = new System.Windows.Forms.Label();
            this.lbresultado = new System.Windows.Forms.Label();
            this.btncalcular = new System.Windows.Forms.Button();
            this.cmbtime = new System.Windows.Forms.ComboBox();
            this.txtResultado = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lbtimes
            // 
            this.lbtimes.AutoSize = true;
            this.lbtimes.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbtimes.Location = new System.Drawing.Point(94, 20);
            this.lbtimes.Name = "lbtimes";
            this.lbtimes.Size = new System.Drawing.Size(60, 25);
            this.lbtimes.TabIndex = 0;
            this.lbtimes.Text = "Times";
            this.lbtimes.Click += new System.EventHandler(this.lbtimes_Click);
            // 
            // lbtime
            // 
            this.lbtime.AutoSize = true;
            this.lbtime.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbtime.Location = new System.Drawing.Point(12, 67);
            this.lbtime.Name = "lbtime";
            this.lbtime.Size = new System.Drawing.Size(56, 25);
            this.lbtime.TabIndex = 1;
            this.lbtime.Text = "Time:";
            this.lbtime.Click += new System.EventHandler(this.lbtime_Click);
            // 
            // lbresultado
            // 
            this.lbresultado.AutoSize = true;
            this.lbresultado.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbresultado.Location = new System.Drawing.Point(7, 172);
            this.lbresultado.Name = "lbresultado";
            this.lbresultado.Size = new System.Drawing.Size(97, 25);
            this.lbresultado.TabIndex = 2;
            this.lbresultado.Text = "Resultado:";
            this.lbresultado.Click += new System.EventHandler(this.lbresultado_Click);
            // 
            // btncalcular
            // 
            this.btncalcular.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncalcular.Location = new System.Drawing.Point(181, 124);
            this.btncalcular.Name = "btncalcular";
            this.btncalcular.Size = new System.Drawing.Size(75, 23);
            this.btncalcular.TabIndex = 3;
            this.btncalcular.Text = "Calcular";
            this.btncalcular.UseVisualStyleBackColor = true;
            this.btncalcular.Click += new System.EventHandler(this.btncalcular_Click);
            // 
            // cmbtime
            // 
            this.cmbtime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbtime.FormattingEnabled = true;
            this.cmbtime.Items.AddRange(new object[] {
            "AMERICA",
            "ATLETICO",
            "CRUZEIRO"});
            this.cmbtime.Location = new System.Drawing.Point(118, 71);
            this.cmbtime.Name = "cmbtime";
            this.cmbtime.Size = new System.Drawing.Size(121, 24);
            this.cmbtime.TabIndex = 4;
            this.cmbtime.SelectedIndexChanged += new System.EventHandler(this.cmbtime_SelectedIndexChanged);
            // 
            // txtResultado
            // 
            this.txtResultado.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.txtResultado.Enabled = false;
            this.txtResultado.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtResultado.Location = new System.Drawing.Point(118, 176);
            this.txtResultado.Name = "txtResultado";
            this.txtResultado.Size = new System.Drawing.Size(138, 22);
            this.txtResultado.TabIndex = 5;
            this.txtResultado.TextChanged += new System.EventHandler(this.txtResultado_TextChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.txtResultado);
            this.Controls.Add(this.cmbtime);
            this.Controls.Add(this.btncalcular);
            this.Controls.Add(this.lbresultado);
            this.Controls.Add(this.lbtime);
            this.Controls.Add(this.lbtimes);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbtimes;
        private System.Windows.Forms.Label lbtime;
        private System.Windows.Forms.Label lbresultado;
        private System.Windows.Forms.Button btncalcular;
        private System.Windows.Forms.ComboBox cmbtime;
        private System.Windows.Forms.TextBox txtResultado;
    }
}

