﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace procontar1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            int numero = 0;
            String sequencia = "";
            numero = int.Parse(txtnumero.Text);

            for (contador = numero; contador <= 10; contador++)
            {
                sequencia = sequencia + contador.ToString() + "/";
            }
            txtsequencia.Text=sequencia;
        }

        public int contador { get; set; }
    }
}