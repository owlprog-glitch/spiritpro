﻿namespace procontar1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbConta = new System.Windows.Forms.Label();
            this.lbNumero = new System.Windows.Forms.Label();
            this.lbSequencia = new System.Windows.Forms.Label();
            this.txtnumero = new System.Windows.Forms.TextBox();
            this.txtsequencia = new System.Windows.Forms.TextBox();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbConta
            // 
            this.lbConta.AutoSize = true;
            this.lbConta.Location = new System.Drawing.Point(136, 23);
            this.lbConta.Name = "lbConta";
            this.lbConta.Size = new System.Drawing.Size(38, 13);
            this.lbConta.TabIndex = 0;
            this.lbConta.Text = "Contar";
            this.lbConta.Click += new System.EventHandler(this.label1_Click);
            // 
            // lbNumero
            // 
            this.lbNumero.AutoSize = true;
            this.lbNumero.Location = new System.Drawing.Point(30, 86);
            this.lbNumero.Name = "lbNumero";
            this.lbNumero.Size = new System.Drawing.Size(44, 13);
            this.lbNumero.TabIndex = 1;
            this.lbNumero.Text = "Numero";
            // 
            // lbSequencia
            // 
            this.lbSequencia.AutoSize = true;
            this.lbSequencia.Location = new System.Drawing.Point(30, 182);
            this.lbSequencia.Name = "lbSequencia";
            this.lbSequencia.Size = new System.Drawing.Size(58, 13);
            this.lbSequencia.TabIndex = 2;
            this.lbSequencia.Text = "Sequencia";
            // 
            // txtnumero
            // 
            this.txtnumero.Location = new System.Drawing.Point(104, 83);
            this.txtnumero.Name = "txtnumero";
            this.txtnumero.Size = new System.Drawing.Size(100, 20);
            this.txtnumero.TabIndex = 3;
            // 
            // txtsequencia
            // 
            this.txtsequencia.Location = new System.Drawing.Point(104, 175);
            this.txtsequencia.Name = "txtsequencia";
            this.txtsequencia.Size = new System.Drawing.Size(100, 20);
            this.txtsequencia.TabIndex = 4;
            this.txtsequencia.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(139, 132);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(75, 23);
            this.btnCalcular.TabIndex = 5;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.txtsequencia);
            this.Controls.Add(this.txtnumero);
            this.Controls.Add(this.lbSequencia);
            this.Controls.Add(this.lbNumero);
            this.Controls.Add(this.lbConta);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbConta;
        private System.Windows.Forms.Label lbNumero;
        private System.Windows.Forms.Label lbSequencia;
        private System.Windows.Forms.TextBox txtnumero;
        private System.Windows.Forms.TextBox txtsequencia;
        private System.Windows.Forms.Button btnCalcular;
    }
}

